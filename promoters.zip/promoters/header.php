<!DOCTYPE html>

<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/favicon.png">
		<!-- Author Meta -->
		<meta name="author" content="Aarya Edutech">
		<!-- Meta Description -->
		<meta name="description" content="Aarya Edutech & Computer Training Center, make your future bright with us. couses available C C++ java Python ADCA Tally Web designing">
		<!-- Meta Keyword -->
		<meta name="keywords" content="Aarya edutech computer center in ranchi courses c c++ java python ADCA Tally DTP Web designing">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>Aarya Edutech & Computer Training Center | Promoters</title>
		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
		<!-- CSS ============================================= -->
		<link rel="stylesheet" href="css/linearicons.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="css/jquery.DonutWidget.min.css">
		<link rel="stylesheet" href="css/bootstrap.css">
		<link rel="stylesheet" href="css/owl.carousel.css">
		<link rel="stylesheet" href="css/main.css">
	</head>
	<body>
		<!-- Start Header Area -->
		<header class="default-header">
			<nav class="navbar navbar-expand-lg  navbar-light">
				<div class="container">
					<a class="navbar-brand" href="index">
						<img src="img/logoa.png" alt="Aarya Edutech">
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
					</button>
					<div class="collapse navbar-collapse justify-content-end align-items-center" id="navbarSupportedContent">
						<ul class="navbar-nav">
							<li><a href="index"><i class="fa fa-home"></i> Home</a></li>
							<li><a href="business"><i class="fa fa-suitcase"></i> Business</a></li>
							<li><a href="contact"><i class="fa fa-phone"></i> Contact</a></li>
							<li><a href="login"><i class="fa fa-lock"></i> Login</a></li>
							<li><a href="register"><i class="fa fa-user"></i> Register</a></li>
						</ul>
					</div>
				</div>
			</nav>
		</header>
		<!-- End Header Area -->