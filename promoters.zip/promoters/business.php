<?php
include "header.php";
?>

<!-- Start banner Area -->
<section class="generic-banner relative">
	<div class="container">
		<div class="row height align-items-center justify-content-center">
			<div class="col-lg-10">
				<div class="generic-banner-content">
					<h2 class="text-white">The Business</h2>
					<p class="text-white"></p>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- End banner Area -->


<?php 
include "footer.php";
?>