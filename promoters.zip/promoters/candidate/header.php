<?php 
session_start();
include '../action/connection.php';
	if($_SESSION['is_login']) {
        //keep user on page
        $sponcer_id = $_SESSION['sponcer_id'];
    }else{
        //redirect to login
        header("Location: ../logout");
    }
?>
<!DOCTYPE html>

<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="../img/favicon.png">
		<!-- Author Meta -->
		<meta name="author" content="Aarya Edutech">
		<!-- Meta Description -->
		<meta name="description" content="Aarya Edutech & Computer Training Center, make your future bright with us. couses available C C++ java Python ADCA Tally Web designing">
		<!-- Meta Keyword -->
		<meta name="keywords" content="Aarya edutech computer center in ranchi courses c c++ java python ADCA Tally DTP Web designing">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>Aarya Edutech & Computer Training Center | Candidate</title>
		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
		<!-- CSS ============================================= -->
		<link rel="stylesheet" href="../css/linearicons.css">
		<link rel="stylesheet" href="../css/font-awesome.min.css">
		<link rel="stylesheet" href="../css/jquery.DonutWidget.min.css">
		<link rel="stylesheet" href="../css/bootstrap.css">
		<link rel="stylesheet" href="../css/owl.carousel.css">
		<link rel="stylesheet" href="../css/main.css">
		<style>
			.blink-text{
				color: #fff;
				font-weight: normal;
				font-size: 1rem;
				animation: blinkingText 2s infinite;
			}
			@keyframes blinkingText{
				0%    { color: blue;}
				25%   { color: red;}
				50%   { color: transparent;}
				75%   { color: red;}
				100%  { color: transparent;}
			}
		</style>
	</head>
	<body>
		<!-- Start Header Area -->
		<header class="default-header">
			<nav class="navbar navbar-expand-lg  navbar-light">
				<div class="container">
					<a class="navbar-brand" href="index">
						<img src="../img/logoa.png" alt="Aarya Edutech">
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
					</button>
					<div class="collapse navbar-collapse justify-content-end align-items-center" id="navbarSupportedContent">
						<ul class="navbar-nav">
							<li><a href="index"><i class="fa fa-home"></i> Dashboard</a></li>
							<li><a href="plan"><i class="fa fa-suitcase"></i> Business plan</a></li>
							<li><a href="tree"><i class="fa fa-sitemap"></i> Tree</a></li>
							<li><a href="../logout"><i class="fa fa-power-off"></i> Logout</a></li>
						</ul>
					</div>
				</div>
			</nav>
		</header>
		<!-- End Header Area -->

		<div class="pt-25" style="background-color: #C800E6;">
			<div class="container">
				<div class="row">
					<div class="col-lg-4 col-md-4 col-12">
						<h6>  Welcome : <?php echo "$sponcer_id";    ?> </h6>
					</div>
					<div class="col-lg-4 col-md-4 col-12">
						<?php
						$sql = "SELECT * FROM `mlm_register` WHERE sponcer_id = $sponcer_id ";
						$query = mysqli_query($con,$sql);
						$res = mysqli_fetch_array($query);
						?>
						<h6><?php echo $res['name']; ?></h6>
					</div>
					<div class="col-lg-4 col-md-4 col-12">
						<h6><?php echo $res['email']; ?></h6>
					</div>
				</div>
			</div>
		</div>