<?php 
include "header.php";

    $search = $sponcer_id;
    function tree_data($sponcer_id){
        global $con;
        $data = array();
        $query = mysqli_query($con,"select * from tree where referal_sponcer_id='$sponcer_id'");
        $result = mysqli_fetch_array($query);
        $data['left'] = $result['left'];
        $data['right'] = $result['right'];
        $data['leftcount'] = $result['leftcount'];
        $data['rightcount'] = $result['rightcount'];
        return $data;
    }

    if(isset($_GET['search-id'])){
        $search_id = mysqli_real_escape_string($con,$_GET['search-id']);
        if($search_id!=""){
            $query_check = mysqli_query($con,"select * from mlm_register where sponcer_id='$search_id'");
            if(mysqli_num_rows($query_check)>0){
                $search = $search_id;
            }
            else{
                echo '<script>alert("Access Denied");window.location.assign("tree.php");</script>';
            }
        }
        else{
            echo '<script>alert("Access Denied");window.location.assign("tree.php");</script>';
        }
    }
?>


<br><br>

<div class="container-fluid">
    <!-- Page Heading ---------------- Content goes here ------------ -->
    <h1 class="text-center m-2">Your Team</h1>
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6 text-center pb-2">
            <form>
                <input type="text" name="search-id" placeholder="Enter sponcer id" required>
                <input type="submit" name="search" value="Search" style="background-color: #400005; color: #fff">
            </form>
        </div>
        <div class="col-md-3"></div>
        <div class="col-lg-12">
            <div class="table-responsive">
                <table class="table" align="center" border="0" style="text-align:center">
                    <tr height="150">
                        <?php
                        $data = tree_data($search);
                        ?>
                        <td><?php echo $data['leftcount'] ?></td>
                        <td colspan="2"><i class="fa fa-user fa-4x" style="color:#1430B1"></i><p><?php echo $search; ?></p></td>
                        <td><?php echo $data['rightcount'] ?></td>
                    </tr>
                    <tr height="150">
                        <?php
                        $first_left_user = $data['left'];
                        $first_right_user = $data['right'];
                        ?>
                        <?php
                        if($first_left_user!=""){
                        ?>
                        <td colspan="2"><a href="tree.php?search-id=<?php echo $first_left_user ?>"><i class="fa fa-user fa-4x" style="color:#D520BE"></i><p><?php echo $first_left_user ?></p></a></td>
                        <?php
                        }
                        else{
                        ?>
                        <td colspan="2"><i class="fa fa-user fa-4x" style="color:#D520BE"></i><p><?php echo $first_left_user ?></p></td>
                        <?php
                        }
                        ?>
                        <?php
                        if($first_right_user!=""){
                        ?>
                        <td colspan="2"><a href="tree.php?search-id=<?php echo $first_right_user ?>"><i class="fa fa-user fa-4x" style="color:#D520BE"></i><p><?php echo $first_right_user ?></p></a></td>
                        <?php
                        }
                        else{
                        ?>
                        <td colspan="2"><i class="fa fa-user fa-4x" style="color:#D520BE"></i><p><?php echo $first_right_user ?></p></td>
                        <?php
                        }
                        ?>
                    </tr>
                    <tr height="150">
                        <?php
                        $data_first_left_user = tree_data($first_left_user);
                        $second_left_user = $data_first_left_user['left'];
                        $second_right_user = $data_first_left_user['right'];
                        $data_first_right_user = tree_data($first_right_user);
                        $third_left_user = $data_first_right_user['left'];
                        $third_right_user = $data_first_right_user['right'];
                        ?>
                        <?php
                        if($second_left_user!=""){
                        ?>
                        <td><a href="tree.php?search-id=<?php echo $second_left_user ?>"><i class="fa fa-user fa-4x" style="color:#361515"></i><p><?php echo $second_left_user ?></p></a></td>
                        <?php
                        }
                        else{
                        ?>
                        <td><i class="fa fa-user fa-4x" style="color:#361515"></i></td>
                        <?php
                        }
                        ?>
                        <?php
                        if($second_right_user!=""){
                        ?>
                        <td><a href="tree.php?search-id=<?php echo $second_right_user ?>"><i class="fa fa-user fa-4x" style="color:#361515"></i><p><?php echo $second_right_user ?></p></a></td>
                        <?php
                        }
                        else{
                        ?>
                        <td><i class="fa fa-user fa-4x" style="color:#361515"></i></td>
                        <?php
                        }
                        ?>
                        <?php
                        if($third_left_user!=""){
                        ?>
                        <td><a href="tree.php?search-id=<?php echo $third_left_user ?>"><i class="fa fa-user fa-4x" style="color:#361515"></i><p><?php echo $third_left_user ?></p></a></td>
                        <?php
                        }
                        else{
                        ?>
                        <td><i class="fa fa-user fa-4x" style="color:#361515"></i></td>
                        <?php
                        }
                        ?>
                        <?php
                        if($third_right_user!=""){
                        ?>
                        <td><a href="tree.php?search-id=<?php echo $third_right_user ?>"><i class="fa fa-user fa-4x" style="color:#361515"></i><p><?php echo $third_right_user ?></p></a></td>
                        <?php
                        }
                        else{
                        ?>
                        <td><i class="fa fa-user fa-4x" style="color:#361515"></i></td>
                        <?php
                        }
                        ?>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>





<?php include "footer.php"; ?>