<?php 
include "header.php";

	if(isset($_POST['submit'])){

        $files = $_FILES['files'];

        $filename = $files['name'];
        $fileerror = $files['error'];
        $filetmp = $files['tmp_name'];

        $fileext = explode('.',$filename);
        $filecheck = strtolower(end($fileext));
        $fileextstored = array('png', 'jpg', 'jpeg');

        if (in_array($filecheck, $fileextstored)) {
            $destinationfile = '../img/'.$filename;
            move_uploaded_file($filetmp, $destinationfile); 
        }
        $sql = "UPDATE `mlm_register` SET `files` = '$destinationfile' WHERE `sponcer_id` = $sponcer_id";
        if($con->query($sql) === true){
            echo '<script language="javascript">';
            echo 'alert("Photograph uploaded Successfully")';
            echo '</script>';
        }
        else{
            echo '<script language="javascript">';
            echo 'alert("Somthing went wrong, please report to Developer")';
            echo '</script>';
        }
        //header('Location:candidate');
    }
?>


<div style="background-color: #0F15AD; color: #fff">
	<div class="container pb-3">
		<div class="pt-3 row">
			<div class="col-lg-4">
				<p><strong>You are in level : &nbsp; " <?php echo $res['level']; ?> "</strong></p>
				<p>To earn more benefits join more candidates.</p>
				<p>your payment status "<b style="color: red;">
					<?php
					$res1=mysqli_query($con,"select * from income where sponcer_id='$sponcer_id'") or die(mysqli_error($con));
						$row1=mysqli_fetch_array($res1);
						echo $row1['payment_status']; 
					?></b>" 
				</p>
			</div>
			<div class="col-lg-2">
				<img src="<?php echo $res['files']; ?>" height="100" width="100" style="border-radius: 100%;" >
			</div>
			<div class="col-lg-6">
				<form method="post" action="" enctype="multipart/form-data">
					<div class="form-group">
						<label><strong>Change Photograph : </strong></label>
						<input type="file" name="files" required>
						<input type="submit" name="submit" class="bg-primary text-white">
					</div>
				</form>
			</div>
		</div>
	</div>
</div>




<div class="container pt-5 pb-5">
	<h4>Important Notes: </h4>
	<h6>How to grow your business</h6>
	<div class="row pt-2">
		<div class="col-lg-4 col-md-4 col-12">
			<ul class="text-justify">
				<p>1. Do not quit your job to start a network marketing business.</p>
				<p>2. Build your network marketing with your current income until you are earning enough to support yourself.</p>
				<p>3. The best way to become a successful network marketer is to help others build their downline. Like your sponsor, be available for people you recruited into the business.</p>
			</ul>
		</div>
		<div class="col-lg-4 col-md-4 col-12">
			<p>4. People like to hear success stories. Share your experiences with other prospects. Helping others will build the depth of your business; this is how the number of people under you grows exponentially.</p>
		</div>
		<div class="col-lg-4 col-md-4 col-12">
			<h5>Your Earnings</h5><hr>
			<!-- <?php
			$res=mysqli_query($con,"select * from income where sponcer_id='$sponcer_id'") or die(mysqli_error($con));
			$row=mysqli_fetch_array($res);
			?> -->
			<strong>Pre earnings: &nbsp;&nbsp; <i class="fa fa-inr"></i> &nbsp;&nbsp; <?php echo $row1['pre_earning']; ?> /-</strong><br>
			<strong>Current earnings: &nbsp;&nbsp; <i class="fa fa-inr"></i> &nbsp;&nbsp; <?php echo $row1['current_earning']; ?> /-</strong><br>
			<strong>Total earnings: &nbsp;&nbsp; <i class="fa fa-inr"></i> &nbsp;&nbsp; <?php echo $row1['pre_earning']+$row1['current_earning']; ?> /-</strong><br>
		</div>
	</div>
</div>



<?php include "footer.php"; ?>