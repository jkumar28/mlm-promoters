
		
		<!-- start footer Area -->
		<footer class="footer-area section-gap">
			<div class="container">
				<div class="row">
					<div class="col-lg-3  col-md-12">
						<div class="single-footer-widget">
							<h6>Need Help / Support</h6>
							<ul class="footer-nav">
								<li>Contact Us</li>
								<li><a href="https://wa.me/+919608038050"><i class="fa fa-whatsapp text-success">&nbsp; 96080 38050</i></a></li>
								<li><a href="tel:+919608038050"><i class="fa fa-phone text-warning">&nbsp; 96080 38050</i></a></li>
								<li></li>
							</ul>
						</div>
					</div>
					<div class="col-lg-6 col-md-12">
						<div class="single-footer-widget newsletter">
							<h6><img src="../img/share.png"> Share & Earn</h6>
							<p>Share with your friends and earn more</p>
							<div id="mc_embed_signup">
							<!-- AddToAny BEGIN -->
							<div class="a2a_kit a2a_kit_size_32 a2a_default_style" data-a2a-url="https://www.aaryaedutech.in/promoters" data-a2a-title="Join our team and earn more, Joining bonus Rs. 500/-  Aarya Edutech Promoters ">
								<a class="a2a_dd" href="https://www.addtoany.com/share"></a>
								<a class="a2a_button_whatsapp"></a>
								<a class="a2a_button_facebook"></a>
							</div>
							<script async src="https://static.addtoany.com/menu/page.js"></script>
							<!-- AddToAny END -->
							</div>
						</div>
					</div>
					<div class="col-lg-3  col-md-12">
						<div class="single-footer-widget mail-chimp">
							<h6 class="mb-20">Instragram Feed</h6>
							<ul class="instafeed d-flex flex-wrap">
								<li><img src="../img/i1.jpg" alt=""></li>
								<li><img src="../img/i2.jpg" alt=""></li>
								<li><img src="../img/i3.jpg" alt=""></li>
								<li><img src="../img/i4.jpg" alt=""></li>
								<li><img src="../img/i5.jpg" alt=""></li>
								<li><img src="../img/i6.jpg" alt=""></li>
								<li><img src="../img/i7.jpg" alt=""></li>
								<li><img src="../img/i8.jpg" alt=""></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="row footer-bottom d-flex justify-content-between">
					<p class="col-lg-8 col-sm-12 footer-text m-0 text-white">Copyright &copy; 2020 </script> All rights reserved | Make in India with <i class="fa fa-heart text-danger" aria-hidden="true"></i> by <a href="https://www.aaryaedutech.in" target="_blank">Aarya Edutech</a></p>
					<div class="col-lg-4 col-sm-12 footer-social">
						<a href="#"><i class="fa fa-facebook"></i></a>
						<a href="https://twitter.com/jkagarwal28"><i class="fa fa-twitter"></i></a>
						<a href="https://www.instagram.com/jkagarwal28" target="_blank"><i class="fa fa-instagram"></i></a>
						<a href="https://wa.me/+919608038050"><i class="fa fa-whatsapp"></i></a>
					</div>
				</div>
			</div>
		</footer>
		<!-- End footer Area -->
		<script src="../js/vendor/jquery-2.2.4.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
		<script src="../js/vendor/bootstrap.min.js"></script>
		<script src="../js/jquery.ajaxchimp.min.js"></script>
		<script src="../js/parallax.min.js"></script>
		<script src="../js/owl.carousel.min.js"></script>
		<script src="../js/jquery.sticky.js"></script>
		<script src="../js/jquery.DonutWidget.min.js"></script>
		<script src="../js/jquery.magnific-popup.min.js"></script>
		<script src="../js/main.js"></script>
	</body>
</html>