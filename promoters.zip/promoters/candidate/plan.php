<?php 
include "header.php";
?>


<div class="container-fluid pt-5 pb-5">
	<h2 class="text-center">How to Speed up your levels</h2>
	<br>
	<div class="pt-2 row text-center">
		<div class="col-lg-3 col-md-3 pt-5 pb-5" style="background-color: #FF6C00; border-radius: 10px;">
			<h6>Level-1</h6><hr>
			<h6>01 : 01 &nbsp;<i class="fa fa-arrow-right"></i>&nbsp; you get <i class="fa fa-inr"></i> 500/-</h6>
			<h6>02 : 02 &nbsp;<i class="fa fa-arrow-right"></i>&nbsp; you get <i class="fa fa-inr"></i> 750/-</h6>
			<h6>03 : 03 &nbsp;<i class="fa fa-arrow-right"></i>&nbsp; you get <i class="fa fa-inr"></i> 1000/-</h6>
			<h6>04 : 04 &nbsp;<i class="fa fa-arrow-right"></i>&nbsp; you get <i class="fa fa-inr"></i> 1250/-</h6>
			<h6>05 : 05 &nbsp;<i class="fa fa-arrow-right"></i>&nbsp; you get <i class="fa fa-inr"></i> 1500/-</h6>
			<h6>06 : 06 &nbsp;<i class="fa fa-arrow-right"></i>&nbsp; you get <i class="fa fa-inr"></i> 1750/-</h6>
			<h6>07 : 07 &nbsp;<i class="fa fa-arrow-right"></i>&nbsp; you get <i class="fa fa-inr"></i> 2000/-</h6>
			<h6>08 : 08 &nbsp;<i class="fa fa-arrow-right"></i>&nbsp; you get <i class="fa fa-inr"></i> 2250/-</h6>
			<h6>09 : 09 &nbsp;<i class="fa fa-arrow-right"></i>&nbsp; you get <i class="fa fa-inr"></i> 2500/-</h6>
			<h6>10 : 10 &nbsp;<i class="fa fa-arrow-right"></i>&nbsp; you get <i class="fa fa-inr"></i> 2750/-</h6>
			<hr>
			<div class="blink-text"><h5>Now you are completed level-1 and get a reward of <i class="fa fa-inr"></i> 20,000/-</h5></div>
		</div>
		<div class="col-lg-3 col-md-3 pt-5 pb-5" style="background-color: #006BCF; border-radius: 10px;">
			<h6>Level-2</h6><hr>
			<h6>15 : 15 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 3000/-</h6>
			<h6>20 : 20 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 3500/-</h6>
			<h6>25 : 25 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 4000/-</h6>
			<h6>30 : 30 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 4500/-</h6>
			<h6>35 : 35 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 5000/-</h6>
			<h6>40 : 40 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 5500/-</h6>
			<h6>50 : 50 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 6000/-</h6>
			<h6>55 : 55 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 6500/-</h6>
			<h6>60 : 60 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 7000/-</h6>
			<h6>65 : 65 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 7500/-</h6>
			<hr>
			<div class="blink-text"><h5>Now you are completed level-2 and get a reward of <i class="fa fa-inr"></i> 70,000/-</h5></div>
		</div>
		<div class="col-lg-3 col-md-3 pt-5 pb-5" style="background-color: #028E2A; border-radius: 10px;">
			<h6>Level-3</h6><hr>
			<h6>70 : 70 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 8000/-</h6>
			<h6>80 : 80 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 9000/-</h6>
			<h6>90 : 90 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 10000/-</h6>
			<h6>100 : 100 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 11000/-</h6>
			<h6>110 : 110 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 12000/-</h6>
			<h6>120 : 120 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 13000/-</h6>
			<h6>130 : 130 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 14000/-</h6>
			<h6>140 : 140 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 15000/-</h6>
			<h6>150 : 150 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 16000/-</h6>
			<h6>160 : 160 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 17000/-</h6>
			<hr>
			<div class="blink-text"><h5>Now you are completed level-3 and get a reward of <i class="fa fa-inr"></i> 3,00,000/-</h5></div>
		</div>
		<div class="col-lg-3 col-md-3 pt-5 pb-5" style="background-color: #ff8c8c; border-radius: 10px;">
			<h6>Level-4</h6><hr>
			<h6>170 : 170 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 18000/-</h6>
			<h6>180 : 180 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 19000/-</h6>
			<h6>190 : 190 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 20000/-</h6>
			<h6>200 : 200 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 21000/-</h6>
			<h6>250 : 250 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 25000/-</h6>
			<h6>300 : 300 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 25000/-</h6>
			<h6>350 : 350 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 25000/-</h6>
			<h6>400 : 400 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 25000/-</h6>
			<h6>450 : 450 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 25000/-</h6>
			<h6>500 : 500 <i class="fa fa-arrow-right"></i> you get <i class="fa fa-inr"></i> 25000/-</h6>
			<hr>
			<div class="blink-text"><h5>Now you are completed level-4 and get a reward of <i class="fa fa-inr"></i> 15,00,000/-</h5></div>
		</div>
	</div>
</div>

<br><br>




<?php include "footer.php"; ?>