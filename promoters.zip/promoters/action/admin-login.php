<?php
    session_start();
    include('connection.php');
    
    if(!isset($_SESSION['is_login'])){

        if(isset($_POST['submit1'])){
            
            $username= $_POST['username'];
            $password= $_POST['password'];

            $sql = "select * from admin where username = '$username' and password = '$password' ";
            $result = $con->query($sql);
            if($result->num_rows > 0){

                $_SESSION['is_login'] = true;
                $_SESSION['username'] = $username;
                header('Location:../admin_dashboard');
            }
            else{
                ?>
                <script>
                    alert("Invalid username or password");
                    window.location="../admin";
                </script>
                <?php
            }
        }
    }else{
        header("Location: ../logout");
    }
?>