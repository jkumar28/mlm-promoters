<?php
    session_start();
    include('connection.php');
    
    if(!isset($_SESSION['is_login'])){

        if(isset($_POST['login-submit'])){
            
            $sponcer_id= $_POST['sponcer_id'];
            $password= $_POST['password'];

            $sql = "select * from mlm_register where sponcer_id = '$sponcer_id' and password = '$password' ";
            $result = $con->query($sql);
            if($result->num_rows > 0){

                $_SESSION['is_login'] = true;
                $_SESSION['sponcer_id'] = $sponcer_id;
                header('Location:../candidate');
            }
            else{
                ?>
                <script>
                    alert("Invalid sponcer id or password");
                    window.location="../login";
                </script>
                <?php
            }
        }
    }else{
        header("Location: ../logout");
    }
?>