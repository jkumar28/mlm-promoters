<?php 
session_start();
include 'connection.php';
	if($_SESSION['is_login']) {
        //keep user on page
        $username = $_SESSION['username'];
    }else{
        //redirect to login
        header("Location: logout");
    }

	$id=$_GET['id'];
    if(isset($_POST['submit2']))
    {
    	mysqli_query($con,"update mlm_register set level='$_POST[level]' where id=$id; ");
    	?>
    	<script>
    		alert("Level updated successfully");
    		window.location="../admin_dashboard"
    	</script>
    	<?php
    }
?>
<!DOCTYPE html>

<html lang="zxx" class="no-js">
<head>
	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Favicon-->
	<link rel="shortcut icon" href="../img/favicon.png">
	<!-- Author Meta -->
	<meta name="author" content="Aarya Edutech">
	<!-- Meta Description -->
	<meta name="description" content="Aarya Edutech & Computer Training Center, make your future bright with us. couses available C C++ java Python ADCA Tally Web designing">
	<!-- Meta Keyword -->
	<meta name="keywords" content="Aarya edutech computer center in ranchi courses c c++ java python ADCA Tally DTP Web designing">
	<!-- meta character set -->
	<meta charset="UTF-8">
	<!-- Site Title -->
	<title>Aarya Edutech & Computer Training Center | Admin dashboard</title>
	<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
	<!-- CSS ============================================= -->
	<link rel="stylesheet" href="../css/linearicons.css">
	<link rel="stylesheet" href="../css/font-awesome.min.css">
	<link rel="stylesheet" href="../css/jquery.DonutWidget.min.css">
	<link rel="stylesheet" href="../css/bootstrap.css">
	<link rel="stylesheet" href="../css/owl.carousel.css">
	<link rel="stylesheet" href="../css/main.css">
</head>
<body>
<!-- Start Header Area -->
<header class="default-header">
	<nav class="navbar navbar-expand-lg  navbar-light">
		<div class="container">
			<a class="navbar-brand" href="index">
				<img src="../img/logoa.png" alt="Aarya Edutech">
			</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse justify-content-end align-items-center" id="navbarSupportedContent">
				<ul class="navbar-nav">
					<li><a href="logout"><i class="fa fa-power-off"></i> Logout</a></li>
				</ul>
			</div>
		</div>
	</nav>
</header>
<!-- End Header Area -->

<div class="pt-25 pb-1" style="background-color: #040A5D;">
	<div class="container">
		<h6>  Welcome : <?php echo $username; ?> </h6>
	</div>
</div>

<br>
<div class="bg-light pt-100 pb-100">
	<div class="container">
		<div class="col-lg-6">
			<h4 class="text-center">Level Update</h4>
			<form method="post" action="">
	        	<?php
	        	$res3=mysqli_query($con,"select * from mlm_register where id='$id' ");
	        	$row3=mysqli_fetch_array($res3);
	        	?>
	        	<div class="form-group">
	        		<label>Sponcer id</label>
	        		<input class="form-control" type="text" name="sponcer_id" value="<?php echo $row3['sponcer_id'] ?>" readonly>
	        	</div>
	        	<div class="form-group">
	        		<label>Level</label>
	        		<input class="form-control" type="text" name="level" value="<?php echo $row3['level'] ?>">
	        	</div>
	        	<div class="form-group">
	        		<input type="submit" name="submit2" value="update" class="btn btn-primary btn-block">
	        	</div>
	        </form>
		</div>
	</div>
</div>

<br>
<!-- start footer Area -->
<footer class="footer-area section-gap">
	<div class="container">
		<div class="row">
			<div class="col-lg-3  col-md-12">
				<div class="single-footer-widget">
					<h6>Need Help / Support</h6>
					<ul class="footer-nav">
						<li>Contact Us</li>
						<li><a href="https://wa.me/+919608038050"><i class="fa fa-whatsapp text-success">&nbsp; 96080 38050</i></a></li>
						<li><a href="tel:+919608038050"><i class="fa fa-phone text-warning">&nbsp; 96080 38050</i></a></li>
						<li></li>
					</ul>
				</div>
			</div>

			<div class="col-lg-6 col-md-12">
				<div class="single-footer-widget newsletter">
					<h6><img src="../img/share.png"> Share & Earn</h6>
					<p>Share with your friends and earn more</p>
					<div id="mc_embed_signup">
					<!-- AddToAny BEGIN -->
					<div class="a2a_kit a2a_kit_size_32 a2a_default_style" data-a2a-url="https://www.aaryaedutech.in/promoters" data-a2a-title="Join our team and earn more, Joining bonus Rs. 500/-  Aarya Edutech Promoters ">
						<a class="a2a_dd" href="https://www.addtoany.com/share"></a>
						<a class="a2a_button_whatsapp"></a>
						<a class="a2a_button_facebook"></a>
					</div>
					<script async src="https://static.addtoany.com/menu/page.js"></script>
					<!-- AddToAny END -->
					</div>
				</div>
			</div>

			<div class="col-lg-3  col-md-12">
				<div class="single-footer-widget mail-chimp">
					<h6 class="mb-20">Instragram Feed</h6>
					<ul class="instafeed d-flex flex-wrap">
						<li><img src="../img/i1.jpg" alt="Aarya Edutech Instragram Feed"></li>
						<li><img src="../img/i2.jpg" alt="Aarya Edutech Instragram Feed"></li>
						<li><img src="../img/i3.jpg" alt="Aarya Edutech Instragram Feed"></li>
						<li><img src="../img/i4.jpg" alt="Aarya Edutech Instragram Feed"></li>
						<li><img src="../img/i5.jpg" alt="Aarya Edutech Instragram Feed"></li>
						<li><img src="../img/i6.jpg" alt="Aarya Edutech Instragram Feed"></li>
						<li><img src="../img/i7.jpg" alt="Aarya Edutech Instragram Feed"></li>
						<li><img src="../img/i8.jpg" alt="Aarya Edutech Instragram Feed"></li>
					</ul>
				</div>
			</div>
		</div>
		<div class="row footer-bottom d-flex justify-content-between">
			<p class="col-lg-8 col-sm-12 footer-text m-0 text-white">Copyright &copy; 2020 </script> All rights reserved | Make in India with <i class="fa fa-heart text-danger" aria-hidden="true"></i> by <a href="https://www.aaryaedutech.in" target="_blank">Aarya Edutech</a></p>
			<div class="col-lg-4 col-sm-12 footer-social">
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="https://twitter.com/jkagarwal28"><i class="fa fa-twitter"></i></a>
				<a href="https://www.instagram.com/jkagarwal28" target="_blank"><i class="fa fa-instagram"></i></a>
				<a href="https://wa.me/+919608038050"><i class="fa fa-whatsapp"></i></a>
			</div>
		</div>
	</div>
</footer>
<!-- End footer Area -->
<script src="js/vendor/jquery-2.2.4.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script src="../js/vendor/bootstrap.min.js"></script>
<script src="../js/jquery.ajaxchimp.min.js"></script>
<script src="../js/parallax.min.js"></script>
<script src="../js/owl.carousel.min.js"></script>
<script src="../js/jquery.sticky.js"></script>
<script src="../js/jquery.DonutWidget.min.js"></script>
<script src="../js/jquery.magnific-popup.min.js"></script>
<script src="../js/main.js"></script>
</body>
</html>