<?php
    session_start();
    include('connection.php');

    if(isset($_POST['submit1'])){
        $side='';
        $referal_sponcer_id = mysqli_real_escape_string($con,$_POST['referal_sponcer_id']);
        $sponcer_id = mysqli_real_escape_string($con,$_POST['sponcer_id']);
        $name = mysqli_real_escape_string($con,$_POST['name']);
        $mobile = mysqli_real_escape_string($con,$_POST['mobile']);
        $email = mysqli_real_escape_string($con,$_POST['email']);
        $password = mysqli_real_escape_string($con,$_POST['password']);
        $c_password = mysqli_real_escape_string($con,$_POST['c_password']);
        $side = mysqli_real_escape_string($con,$_POST['side']);
        
        function random_strings($length_of_string){
            $str_result = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
            return substr(str_shuffle($str_result),0, $length_of_string);
        }
        $token = random_strings(15);

        $pass = password_hash($password, PASSWORD_BCRYPT);
        $c_pass = password_hash($c_password, PASSWORD_BCRYPT);

        $email_query = "select * from mlm_register where email ='$email' " ;
        $e_query = mysqli_query($con,$email_query);
        $email_count = mysqli_num_rows($e_query);

        $referal_sponcer_query = "select * from mlm_register where  referal_sponcer_id = '$referal_sponcer_id' " ;
        $rs_query = mysqli_query($con,$referal_sponcer_query);
        $referal_sponcer_count = mysqli_num_rows($rs_query);

        $sponcer_query = "select * from mlm_register where sponcer_id = '$sponcer_id' " ;
        $s_query = mysqli_query($con,$sponcer_query);
        $sponcer_count = mysqli_num_rows($s_query);

        $mobile_query = "select * from mlm_register where mobile = '$mobile' " ;
        $m_query = mysqli_query($con,$mobile_query);
        $mobile_count = mysqli_num_rows($m_query);

        $side_query = "select * from mlm_register where side = '$side' and referal_sponcer_id='$referal_sponcer_id' " ;
        $s_query = mysqli_query($con,$side_query);
        $side_count = mysqli_num_rows($s_query);

        if($side_count>0){
            ?>
            <script type="text/javascript">
            alert("This side is already used ! Choose another side");
            window.location="../register";
            </script>
            <?php
        }
        elseif($email_count > 0) {
            ?>
            <script type="text/javascript">
            alert("This email is already exist ! Use another");
            window.location="../register";
            </script>
            <?php
        } 
        elseif($referal_sponcer_count > 1) {
            ?>
            <script type="text/javascript">
            alert("You can not use this referal id, use another");
            window.location="../register";
            </script>
            <?php
        } 
        elseif($sponcer_count > 0) {
            ?>
            <script type="text/javascript">
            alert("This Sponcer id is already used, Try another");
            window.location="../register";
            </script>
            <?php
        } 
        elseif($mobile_count > 0){
            ?>
            <script type="text/javascript">
            alert("This Mobile number is already used, Try another");
            window.location="../register";
            </script>
            <?php
        } 
        elseif($password === $c_password){

            $query = mysqli_query($con,"INSERT INTO `mlm_register`(`referal_sponcer_id`, `sponcer_id`, `name`, `mobile`, `email`, `password`, `token`, `side`) VALUES 
            ('$referal_sponcer_id','$sponcer_id','$name','$mobile','$email','$password','$token','$side')") or die(mysqli_error($con));

            $query = mysqli_query($con,"insert into tree(`referal_sponcer_id`) values('$sponcer_id')") or die(mysqli_error($con));

            $query = mysqli_query($con,"update tree set `$side`='$sponcer_id' where referal_sponcer_id='$referal_sponcer_id'") or die(mysqli_error($con));

            $query = mysqli_query($con,"insert into income (`sponcer_id`) values('$sponcer_id')") or die(mysqli_error($con));

            //Update count 
            $userid=$sponcer_id;
            $under_userid=$referal_sponcer_id;

            $temp_under_userid = $under_userid;
            $temp_side_count = $side.'count'; //leftcount or rightcount
            
            $temp_side = $side;
            $total_count=1;
            $i=1;
            if($total_count>0){
                $i;
                $q = mysqli_query($con,"select * from tree where referal_sponcer_id='$temp_under_userid'");
                $r = mysqli_fetch_array($q);
                $current_temp_side_count = $r[$temp_side_count]+1;
                $temp_under_userid;
                $temp_side_count;
                mysqli_query($con,"update tree set `$temp_side_count`=$current_temp_side_count where referal_sponcer_id='$temp_under_userid'") or die(mysqli_error($con));
            }

            ?>
            <script type="text/javascript">
                alert("Registration Successfull ! Please Login");
                window.location="../register";
            </script>
            <?php
        } else{
            ?>
            <script type="text/javascript">
                alert("Password do not match");
                window.location="../register";
            </script>
            <?php
        }
    }

function tree($sponcer_id){
    global $con;
    $data = array();
    $query = mysqli_query($con,"select * from tree where referal_sponcer_id='$sponcer_id'");
    $result = mysqli_fetch_array($query);
    $data['left'] = $result['left'];
    $data['right'] = $result['right'];
    $data['leftcount'] = $result['leftcount'];
    $data['rightcount'] = $result['rightcount'];
    
    return $data;
}

?>
