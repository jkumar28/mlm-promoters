<?php
session_start();
include "action/connection.php";
include "header.php";
?>

<div class="mt-100 mb-100">
	<div class="container">
		<div class="row">
			<div class="col-lg-6">
				<h2>Registration Form</h2>
				<p>Register Yourself to get more benefits</p>

				<form action="action/registration.php" class="was-validated" method="post">
					<div class="form-group">
						<label>Referal Sponcer Id</label>
						<input type="text" class="form-control" placeholder="Enter Referal Sponcer Id" name="referal_sponcer_id" required maxlength="8">
					</div>
					<div class="form-group">
						<label>Sponcer Id</label>
						<input type="text" class="form-control" placeholder="Enter Sponcer Id" name="sponcer_id" required maxlength="8">
					</div>
					<div class="form-group">
						<label>Full Name</label>
						<input type="text" class="form-control" placeholder="Enter Full Name" name="name" required>
					</div>
					<div class="form-group">
						<label>Email</label>
						<input type="email" class="form-control" placeholder="Enter Email Id" name="email" required>
					</div>
					<div class="form-group">
						<label>Contact</label>
						<input type="text" class="form-control" placeholder="Enter Mobile Number" name="mobile" required maxlength="10">
					</div>
					<div class="form-group">
						<label>Password:</label>
						<input type="password" class="form-control" placeholder="Enter password" name="password" required>
					</div>
					<div class="form-group">
						<label>Confirm Password</label>
						<input type="password" class="form-control" placeholder="Repeat password" name="c_password" required>
					</div>
					<div class="form-group">
						<label>Joining Side : </label>
						<input type="radio" name="side" value="left"> Left
                        <input type="radio" name="side" value="right"> Right
					</div>
					<div class="form-group form-check">
						<label class="form-check-label">
							<input class="form-check-input" type="checkbox" name="remember" required> I agree Terms & Condition.
							<div class="invalid-feedback">Check this checkbox to continue.</div>
						</label>
					</div>
					<input type="submit" name="submit1" class="btn btn-primary btn-block">
				</form>
			</div>
		</div>
	</div>
</div>













<?php 
include "footer.php";
?>

