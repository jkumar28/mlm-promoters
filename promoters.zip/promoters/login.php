<?php
session_start();
include "header.php";
include "action/connection.php";
?>

<div class="mt-100 mb-100">
	<div class="container">
		<div class="row">
			<div class="col-lg-6">
				<h2>Login</h2>
				<p></p>

				<form action="action/login.php" class="was-validated" method="post">
					
					<div class="form-group">
						<label>Sponcer Id</label>
						<input type="text" class="form-control" placeholder="Enter Sponcer Id" name="sponcer_id" required maxlength="8">
					</div>
					
					<div class="form-group">
						<label>Password</label>
						<input type="password" class="form-control" placeholder="Enter Password" name="password" required>
					</div>

					<div class="form-group">
						<a style="float: right;" href="forgot-password">Forgot Password</a>
					</div>
					<br><br>
					<input type="submit" name="login-submit" value="Login" class="btn btn-primary btn-block">
				</form>
			</div>
		</div>
	</div>
</div>





<?php 
include "footer.php";
?>