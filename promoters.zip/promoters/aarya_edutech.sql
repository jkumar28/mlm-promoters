-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 28, 2020 at 09:40 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aarya_edutech`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(5) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'Admin', 'admin12345');

-- --------------------------------------------------------

--
-- Table structure for table `income`
--

CREATE TABLE `income` (
  `id` int(5) NOT NULL,
  `sponcer_id` varchar(50) DEFAULT NULL,
  `payment_status` varchar(10) NOT NULL DEFAULT 'Not done',
  `pre_earning` varchar(10) NOT NULL DEFAULT '0',
  `current_earning` varchar(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `income`
--

INSERT INTO `income` (`id`, `sponcer_id`, `payment_status`, `pre_earning`, `current_earning`) VALUES
(1, '20201234', 'done', '200', '100'),
(2, '20201235', 'done', '400', '0'),
(3, '20201236', 'Not done', '0', '0'),
(4, '20201237', 'Not done', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `mlm_register`
--

CREATE TABLE `mlm_register` (
  `id` int(30) NOT NULL,
  `referal_sponcer_id` varchar(30) NOT NULL,
  `sponcer_id` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `joining_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `files` varchar(30) NOT NULL DEFAULT '	 img/default_avatar.png',
  `token` varchar(255) NOT NULL,
  `side` varchar(10) NOT NULL,
  `level` int(5) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mlm_register`
--

INSERT INTO `mlm_register` (`id`, `referal_sponcer_id`, `sponcer_id`, `name`, `mobile`, `email`, `password`, `joining_date`, `files`, `token`, `side`, `level`) VALUES
(1, 'Admin', '20201234', 'Jitendra', '6203511518', 'jkagarwal1912@gmail.com', '////////', '2020-08-27 19:12:03', '../img/default_avatar.png', '', '', 123),
(2, '20201234', '20201235', 'user1', 'user1', 'user1@gmail.com', 'aa', '2020-08-27 19:14:35', '../img/default_avatar.png', 'lZgxcFy6RhiI5Hf', 'left', 12),
(3, '20201234', '20201236', 'user2', 'user2', 'user2@gmail.com', 'aa', '2020-08-27 19:19:23', '../img/default_avatar.png', 'G9ECeAIkjWJBZFM', 'right', 0),
(5, '20201235', '20201237', 'user3', 'user3', 'user3@gmail.com', 'aa', '2020-08-27 19:49:42', '../img/i6.jpg', 'G38XJPsUzcQ4evF', 'left', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tree`
--

CREATE TABLE `tree` (
  `id` int(11) NOT NULL,
  `referal_sponcer_id` varchar(50) NOT NULL,
  `left` varchar(50) DEFAULT NULL,
  `right` varchar(50) DEFAULT NULL,
  `leftcount` int(11) DEFAULT '0',
  `rightcount` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tree`
--

INSERT INTO `tree` (`id`, `referal_sponcer_id`, `left`, `right`, `leftcount`, `rightcount`) VALUES
(1, '20201234', '20201235', '20201236', 2, 1),
(2, '20201235', '20201237', NULL, 1, 0),
(3, '20201236', NULL, NULL, 0, 0),
(5, '20201237', NULL, NULL, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `income`
--
ALTER TABLE `income`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mlm_register`
--
ALTER TABLE `mlm_register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tree`
--
ALTER TABLE `tree`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `income`
--
ALTER TABLE `income`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `mlm_register`
--
ALTER TABLE `mlm_register`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tree`
--
ALTER TABLE `tree`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
