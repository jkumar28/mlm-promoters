<?php include "header.php"; ?>
		
		<!-- start banner Area -->
		<section class="banner-area relative" id="home" data-parallax="scroll" data-image-src="img/header-bg.jpg">
			<div class="overlay-bg overlay"></div>
			<div class="container">
				<div class="row fullscreen  d-flex align-items-center justify-content-end">
					<div class="banner-content col-lg-6 col-md-12">
						<h1>
						We Provide  <br>
						<span>Solutions</span> that <br>
						Brings <span>Joy</span>
						</h1>
						<a href="register" class="primary-btn2 header-btn text-uppercase">Join Us Now !</a>
					</div>
				</div>
			</div>
		</section>
		<!-- End banner Area -->
		
		<!-- start service Area-->
		<section class="service-area pt-100 pb-150" id="service">
			<div class="container">
				<div class="row d-flex justify-content-center">
					<div class="menu-content pb-70 col-lg-8">
						<div class="title text-center">
							<h1 class="mb-10">Why Join Aarya Edutech ?</h1>
							<p></p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="sigle-service col-lg-3 col-md-6">
						<span class="lnr lnr-rocket"></span>
						<h4>Easy Join</h4>
						<p>Join candidates and make your team, click on Registration button to join us and improve your career with us. we give you a lot of opportunity, So don't miss the time, Register Now</p>
						<a href="register" class="text-uppercase primary-btn2 primary-border circle">Register Now</a>
					</div>
					<div class="sigle-service col-lg-3 col-md-6">
						<span class="lnr lnr-magic-wand"></span>
						<h4>No-Target</h4>
						<p>Aarya edutech offers you to get a successfull personality in the society, It helps you to bring achievements in your life. We does not give you any type of Target for promotion.</p>
						<a href="#" class="text-uppercase primary-btn2 primary-border circle">View Details</a>
					</div>
					<div class="sigle-service col-lg-3 col-md-6">
						<span class="lnr lnr-gift"></span>
						<h4>Holiday Packages</h4>
						<p>Aarya edutech gives you a free holiday couple package after completing 4th level. Best way of experiencing, huge incentive join us, We helps you to live your dream life.</p>
						<a href="#" class="text-uppercase primary-btn2 primary-border circle">View Details</a>
					</div>
					<div class="sigle-service col-lg-3 col-md-6">
						<span class="lnr lnr-phone"></span>
						<h4>Dedicated Support</h4>
						<p>Aarya edutech always support their candidates, 24/7 support service available. Feel free to contact us everytime.</p><br>
						<a href="https://wa.me/+916203511518" class="text-uppercase primary-btn2 primary-border circle"><i class="fa fa-whatsapp text-success font-weight-bold"></i> &nbsp; Contact</a>
					</div>
				</div>
			</div>
		</section>
		<!-- end service Area-->

		<!-- Start About Area -->
		<section class="about-area">
			<div class="container-fluid">
				<div class="row justify-content-end align-items-center d-flex no-padding">
					<div class="col-lg-6 about-left mt-70">
						<h1>We can be your digital <br>
						Problems Solution Partner</h1>
						<p> </p>
						<div class="buttons">
							<!-- you can add buttons here -->
						</div>
					</div>
					<div class="col-lg-6 about-right">
						<img class="img-fluid" src="img/about.png" alt="">
					</div>
				</div>
			</div>
		</section>
		<!-- End About Area -->

		<!-- Start project Area -->
		<section class="project-area section-gap" id="project">
			<div class="container">
				<div class="row d-flex justify-content-center">
					<div class="menu-content pb-40 col-lg-8">
						<div class="title text-center">
							<h1 class="mb-10">Latest Project on the go</h1>
							<p></p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="active-works-carousel mt-40">
						<div class="item">
							<a href="https://jkonlinetestportal.pragatiengineering.co.in/" target="_blank">
								<img class="img-fluid" src="img/online-test.jpg" alt="online test series">
							</a>
							<div class="caption text-center mt-20">
								<h6 class="text-uppercase">Join Online Test Series</h6>
								<p></p>
							</div>
						</div>
						<div class="item">
							<img class="img-fluid" src="img/project.jpg" alt="latest project">
							<div class="caption text-center mt-20">
								<h6 class="text-uppercase">Latest Project</h6>
								<p></p>
							</div>
						</div>
						<div class="item">
							<img class="img-fluid" src="img/project3.jpg" alt="aarya edutech">
							<div class="caption text-center mt-20">
								<h6 class="text-uppercase">Latest Project</h6>
								<p></p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End project Area -->
		<div class="bg-light pt-100 pb-100">
			<div class="container">
				<h3 class="text-center">How Team Works ?</h3><br><br>
				<div class="table table-responsive text-center">
					<table class="table">
						<tr>
							<td colspan="4"><i class="fa fa-user text-primary fa-4x"></i><br>User</td>
						</tr>
						<tr>
							<td colspan="2"><i class="fa fa-user text-success fa-4x"></i><br>User 1</td>
							<td colspan="2"><i class="fa fa-user text-success fa-4x"></i><br>User 2</td>
						</tr>
						<tr>
							<td><i class="fa fa-user text-info fa-4x"></i><br>User 3</td>
							<td><i class="fa fa-user text-info fa-4x"></i><br>User 4</td>
							<td><i class="fa fa-user text-info fa-4x"></i><br>User 5</td>
							<td><i class="fa fa-user text-info fa-4x"></i><br>User 6</td>
						</tr>
					</table>
				</div>
			</div>
		</div>	
		
		<!-- Start skill Area -->
		<section class="skill-area section-gap">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 skill-left">
						<h1 class="text-white mb-30">Our Fields of Expertness</h1>
						<p></p>
					</div>
					<div class="col-lg-6 skill-right">
						<div class="row d-flex justify-content-center">
							<div class="col-lg-4 col-md-4 single-skill">
								<div class="skill1 d-block mx-auto"></div>
								<h4>Power</h4>
							</div>
							<div class="col-lg-4 col-md-4 single-skill">
								<div class="skill2 d-block mx-auto"></div>
								<h4>Energy</h4>
							</div>
							<div class="col-lg-4 col-md-4 single-skill">
								<div class="skill3 d-block mx-auto"></div>
								<h4>Resources</h4>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End skill Area -->
		
		
		<!-- Start team Area -->
		<section class="team-area section-gap" id="team">
			<div class="container">
				<div class="row d-flex justify-content-center">
					<div class="menu-content pb-70 col-lg-8">
						<div class="title text-center">
							<h1 class="mb-10">Our Creative Team</h1>
							<p>Who are in extremely love with eco friendly system.</p>
						</div>
					</div>
				</div>
				<div class="row justify-content-center d-flex align-items-center">
					<div class="col-md-3 single-team">
						<div class="thumb">
							<img class="img-fluid" src="img/t1a.jpg" alt="">
							<div class="align-items-center justify-content-center d-flex">
								<a href="#"><i class="fa fa-facebook"></i></a>
								<a href="#"><i class="fa fa-twitter"></i></a>
								<a href="#"><i class="fa fa-linkedin"></i></a>
							</div>
						</div>
						<div class="meta-text mt-30 text-center">
							<h4>Dileep Kumar</h4>
							<p>Director</p>
						</div>
					</div>
					<div class="col-md-3 single-team">
						<div class="thumb">
							<img class="img-fluid" src="img/t3a.jpg" alt="">
							<div class="align-items-center justify-content-center d-flex">
								<a href="#"><i class="fa fa-facebook"></i></a>
								<a href="#"><i class="fa fa-twitter"></i></a>
								<a href="#"><i class="fa fa-linkedin"></i></a>
							</div>
						</div>
						<div class="meta-text mt-30 text-center">
							<h4>Jiya Mehta</h4>
							<p>CEO</p>
						</div>
					</div>
					<div class="col-md-3 single-team">
						<div class="thumb">
							<img class="img-fluid" src="img/t2a.jpg" alt="">
							<div class="align-items-center justify-content-center d-flex">
								<a href="#"><i class="fa fa-facebook"></i></a>
								<a href="#"><i class="fa fa-twitter"></i></a>
								<a href="#"><i class="fa fa-linkedin"></i></a>
							</div>
						</div>
						<div class="meta-text mt-30 text-center">
							<h4>Roshan Kumar</h4>
							<p>Marketing Manager</p>
						</div>
					</div>
					<div class="col-md-3 single-team">
						<div class="thumb">
							<img class="img-fluid" src="img/jk.jpg" alt="">
							<div class="align-items-center justify-content-center d-flex">
								<a href="#"><i class="fa fa-facebook"></i></a>
								<a href="#"><i class="fa fa-twitter"></i></a>
								<a href="#"><i class="fa fa-linkedin"></i></a>
							</div>
						</div>
						<div class="meta-text mt-30 text-center">
							<h4>Jitendra Agarwal</h4>
							<p>Co-founder & Business Developer</p>
						</div>
					</div>
					
				</div>
			</div>
		</section>
		<!-- End team Area -->

		<!-- Start testimonial Area -->
		<section class="testimonial-area relative section-gap">
			<div class="overlay overlay-bg"></div>
			<div class="container">
				<div class="row">
					<div class="active-testimonial">
						<div class="single-testimonial item d-flex flex-row">
							<div class="thumb">
								<img class="img-fluid" src="img/user1.png" alt="">
							</div>
							<div class="desc">
								<p>This is the best computer institute in ranchi. I learned a lot through this institute, their teachers are good in nature and friendly behaviour.<br>Thanks to Aarya Edutech !</p>
								<h4 mt-30>Naina Kumari</h4>
								<p>Student at Aarya Edutech</p>
							</div>
						</div>

						<div class="single-testimonial item d-flex flex-row">
							<div class="thumb">
								<img class="img-fluid" src="img/user3.png" alt="">
							</div>
							<div class="desc">
								<p>Great Institute, I completed my DCA and Tally from this institute and now i am working in a company in Ranchi.<br>Thanks! Aarya Edutech.</p>
								<h4 mt-30>Prakash Kumar</h4>
								<p>Student at Aarya Edutech</p>
							</div>
						</div>

						<div class="single-testimonial item d-flex flex-row">
							<div class="thumb">
								<img class="img-fluid" src="img/user2.png" alt="">
							</div>
							<div class="desc">
								<p>This is the best computer institute in ranchi. I learned a lot through this institute, their teachers are good in nature and friendly behaviour.<br>Thanks to Aarya Edutech !</p>
								<h4 mt-30>Roshni Kumari</h4>
								<p>Student at Aarya Edutech</p>
							</div>
						</div>

					</div>
				</div>
			</div>
		</section>
		<!-- End testimonial Area -->
		
		<?php include "footer.php"; ?>