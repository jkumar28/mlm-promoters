<?php
session_start();
include "header.php";
?>

<div class="mt-100 mb-100">
	<div class="container">
		<div class="row">
			<div class="col-lg-6">
				<h2>Admin Login</h2>
				<p></p>

				<form action="action/admin-login.php" class="was-validated" method="post">
					
					<div class="form-group">
						<label>Username</label>
						<input type="text" class="form-control" placeholder="Username" name="username" required maxlength="8">
					</div>
					
					<div class="form-group">
						<label>Password</label>
						<input type="password" class="form-control" placeholder="Enter Password" name="password" required>
					</div>
					<br>
					<input type="submit" name="submit1" value="Admin Login" class="primary-btn2 primary-border header-btn btn-block">
				</form>
			</div>
		</div>
	</div>
</div>



<?php 
include "footer.php";
?>